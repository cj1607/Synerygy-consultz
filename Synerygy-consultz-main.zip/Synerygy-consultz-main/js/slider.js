$(document).ready(function () {
    $('.slider-nav').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        dots: false,
        focusOnSelect: false,
        autoplay: true,
        pauseOnHover: false,
        pauseOnFocus: false,
        speed: 1000
    });
});